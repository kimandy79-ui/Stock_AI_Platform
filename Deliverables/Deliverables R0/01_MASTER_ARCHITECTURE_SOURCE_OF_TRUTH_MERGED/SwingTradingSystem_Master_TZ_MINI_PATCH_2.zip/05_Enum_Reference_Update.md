# Update SCHEMA/12_Enum_Values_Reference.md

## list_membership

Used in `sim_signal_outcomes`.

Values:
- raw_only
- diversified_only
- both

## list_type

Used in `sim_config_comparisons`.

Values:
- raw
- diversified

## selected column semantics

V1 meanings:

```text
selected_flag = in_diversified_top_n
selected_top_n = in_raw_top_n OR in_diversified_top_n
```

Preferred new fields:
- in_raw_top_n
- in_diversified_top_n
