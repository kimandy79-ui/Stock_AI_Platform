# Claude Review Prompt — MINI-PATCH 2

You are reviewing MINI-PATCH 2 for the already green-lighted SwingTradingSystem Master TZ.

Context:
PATCH 1 was accepted, but you identified that several base Master TZ documents still contained old contradictory formulas or missing enum/semantic definitions.

Do NOT reopen architecture review.
Do NOT redesign the system.
This is a consistency patch.

Please verify that MINI-PATCH 2 correctly fixes:

1. Outcome formulas:
   - return/MFE/MAE/R-multiple use entry_price_sim
   - entry_price_raw is audit reference only

2. Step 4 formulas:
   - stop/target/estimated_rr use entry_proxy_raw
   - entry_proxy_raw = signal_date close_raw

3. Feature formula:
   - avg_dollar_volume_20d uses close_raw * volume_raw
   - volume_adj is reserved / unused in V1

4. Step 5 formula:
   - hard_cap_enabled TRUE means reject over-cap candidates and no soft penalty
   - hard_cap_enabled FALSE means use soft penalties
   - no double punishment

5. Enum/reference updates:
   - list_membership = raw_only / diversified_only / both
   - list_type = raw / diversified
   - selected_flag = in_diversified_top_n
   - selected_top_n = in_raw_top_n OR in_diversified_top_n

6. Schema Manager note:
   - patch columns must be merged into CREATE TABLE definitions for fresh DB
   - not applied as ALTER TABLE immediately after creating old schema

7. Pipeline note:
   - outcome queue tracks proposals where in_raw_top_n OR in_diversified_top_n

Return in this structure:
1. Executive Verdict — ACCEPT / MODIFY / REJECT
2. Are all PATCH 1 contradictions closed?
3. Any remaining schema contradictions?
4. Any remaining formula contradictions?
5. Does this block Modules 01–04?
6. Which modules must wait until MINI-PATCH 2 is applied?
7. Minimum required changes, if any.
8. Final Recommendation.

Be strict but practical.
