# SwingTradingSystem Master TZ — MINI-PATCH 2

Purpose:
MINI-PATCH 2 closes consistency gaps found during Claude's PATCH 1 review.

This is not an architecture change.
This is a formula/schema consistency patch.

Fixes:
1. Outcome formulas use `entry_price_sim`, not `entry_price_raw`.
2. Step 4 stop/target formulas use `entry_proxy_raw`, not future next-day entry.
3. Avg dollar volume formula uses `close_raw * volume_raw`.
4. Step 5 final score distinguishes hard-cap vs soft-penalty mode.
5. Enum reference includes `list_membership` and `list_type`.
6. Legacy selected columns are semantically defined.
7. Schema Manager must merge patch columns into final CREATE TABLE definitions, not apply ALTER TABLE on fresh DB.
