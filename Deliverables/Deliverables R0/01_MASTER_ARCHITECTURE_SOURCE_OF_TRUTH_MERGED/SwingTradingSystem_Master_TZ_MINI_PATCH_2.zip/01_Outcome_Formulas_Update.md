# Update FORMULAS/64_Outcome_Calculation_Rules.md

## Final definitions

`entry_price_raw = next trading day open_raw`

Used for:
- audit
- execution reference

`entry_price_sim = open_raw * (1 + slippage_bps / 10000)`

Used for:
- return_5bd_pct
- return_10bd_pct
- return_20bd_pct
- return_40bd_pct
- mfe_40bd_pct
- mae_40bd_pct
- realized_r_multiple

## Final formulas

```text
return_Nbd_pct = close_adj_Nbd / entry_price_sim - 1
```

```text
mfe_40bd_pct = max(high_adj over entry_date to 40bd eval date) / entry_price_sim - 1
```

```text
mae_40bd_pct = min(low_adj over entry_date to 40bd eval date) / entry_price_sim - 1
```

```text
realized_r_multiple = (exit_price_sim_equivalent - entry_price_sim) / (entry_price_sim - stop_price_raw)
```
