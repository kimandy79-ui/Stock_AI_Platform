# Update FORMULAS/62_Scoring_Formulas_Step4.md

## Add named variable

```text
entry_proxy_raw = close_raw on signal_date
```

## Replace stop/target formulas

```text
stop_price_raw = min(recent_20d_low_raw, entry_proxy_raw - 1.5 * atr14_raw_equivalent)
```

```text
target_price_raw = entry_proxy_raw + target_R * (entry_proxy_raw - stop_price_raw)
```

```text
estimated_rr = (target_price_raw - entry_proxy_raw) / (entry_proxy_raw - stop_price_raw)
```

## Gap warning
When actual next-day open is known:

```text
if abs(open_raw_next_day / entry_proxy_raw - 1) > 0.05:
    log warning
```

Do not recompute the original mechanical Step 4 signal.
