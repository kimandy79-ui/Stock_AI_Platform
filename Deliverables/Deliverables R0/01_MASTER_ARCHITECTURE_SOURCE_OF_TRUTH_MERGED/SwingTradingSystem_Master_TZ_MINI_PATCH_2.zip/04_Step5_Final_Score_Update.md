# Update FORMULAS/63_Scoring_Formulas_Step5.md

## Final rule

### If hard_cap_enabled = TRUE

If candidate exceeds sector or industry cap:

```text
reject candidate from diversified list
diversified_rank = NULL
rejection_reason = sector_cap or industry_cap
```

If candidate does not exceed cap:

```text
proposal_score_final = proposal_score_raw
```

No soft penalty is applied in hard-cap mode in V1.

### If hard_cap_enabled = FALSE

No hard rejection.

Apply soft penalties:

```text
proposal_score_final = proposal_score_raw * sector_penalty * industry_penalty
```

## Legacy compatibility

```text
selected_flag = in_diversified_top_n
selected_top_n = in_raw_top_n OR in_diversified_top_n
```
