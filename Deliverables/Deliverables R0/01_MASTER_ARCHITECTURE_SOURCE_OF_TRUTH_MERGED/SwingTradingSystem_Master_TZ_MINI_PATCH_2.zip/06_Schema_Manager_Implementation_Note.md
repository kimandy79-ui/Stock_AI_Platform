# Schema Manager Implementation Note

PATCH 1 and MINI-PATCH 2 contain ALTER TABLE snippets for clarity.

For a fresh database, Module 03 Schema Manager must merge patch columns into final CREATE TABLE definitions.

Do NOT:
1. create old base tables;
2. then immediately run patch ALTER TABLE statements.

## Required final schema state

### signal_outcomes
- entry_price_raw
- entry_price_sim
- cross_fold_outcome

### sim_signal_outcomes
- entry_price_raw
- entry_price_sim
- cross_fold_outcome
- list_membership

### step5_proposals
- raw_rank
- diversified_rank
- in_raw_top_n
- in_diversified_top_n
- diversification_applied
- selected_flag
- selected_top_n
- rejection_reason

### sim_step5_proposals
- raw_rank
- diversified_rank
- in_raw_top_n
- in_diversified_top_n
- diversification_applied
- rejection_reason

### sim_config_comparisons
- list_type
