# MINI-PATCH 2 Application Checklist

Apply before Module 03 final schema:
- merge entry_price_sim into CREATE TABLE definitions
- merge raw/diversified ranking fields into CREATE TABLE definitions
- merge list_membership and list_type into simulation schema
- add indexes for raw/diversified rank
- define legacy selected column semantics

Apply before Module 11 Feature Engine:
- avg_dollar_volume_20d = close_raw * volume_raw
- volume_adj reserved / unused

Apply before Module 14 Step4:
- use entry_proxy_raw = signal_date close_raw

Apply before Module 15 Step5:
- hard-cap vs soft-penalty branch logic
- selected_flag and selected_top_n semantics
- raw/diversified rank logic

Apply before Module 16 Outcome Queue:
- use entry_price_sim for performance
- track raw OR diversified Top 20

Apply before Module 17 Simulation:
- list_membership and list_type enums/columns

Modules 01 and 02 can start immediately.
Module 03 can start only if final merged schema is used.
