# Update FORMULAS/60_Feature_Formulas_Complete.md

## Replace avg dollar volume formula

```text
avg_dollar_volume_20d = mean(close_raw * volume_raw over prior 20 trading days)
```

## volume_adj V1 rule

`volume_adj` is reserved and unused in V1 feature formulas.

All V1 volume features use:

```text
volume_raw
```
