# Update PIPELINE/70_Pipeline_Orchestrator_Spec.md

Add to outcome queue generation step:

Outcome queue tasks are created for proposals where:

```text
in_raw_top_n = TRUE
OR
in_diversified_top_n = TRUE
```

Reason:
The system must track both raw Top 20 and diversified Top 20 performance.
