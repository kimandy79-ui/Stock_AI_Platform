# Claude Patch Review Prompt

You are reviewing PATCH 1 for the already green-lighted SwingTradingSystem Master TZ.

Do not reopen the architecture review.

Please verify whether this patch correctly applies:
1. entry_price_raw vs entry_price_sim clarification;
2. Step4 close_raw entry proxy for stop/target;
3. zero-padded feature schema version;
4. hard cap / soft penalty interaction;
5. avg_dollar_volume formula cleanup;
6. volume_adj reserved status;
7. raw_rank and diversified_rank change;
8. outcome tracking for raw OR diversified Top 20;
9. simulation list_type / list_membership fields;
10. UI checkbox behavior.

Return:
1. Executive Verdict — ACCEPT / MODIFY / REJECT
2. Any contradictions introduced?
3. Any schema patch missing?
4. Any formula patch missing?
5. Does this block Module 01–04 coding?
6. Minimum changes needed, if any.

Be strict but practical.
