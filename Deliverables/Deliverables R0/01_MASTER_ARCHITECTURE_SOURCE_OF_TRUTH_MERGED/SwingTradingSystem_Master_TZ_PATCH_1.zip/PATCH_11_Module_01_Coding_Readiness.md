# Patch 11 — Module 01 Coding Readiness

Module 01 can start now.

Include pinned dependencies in Module 01 prompt:

```text
duckdb>=0.10
polars>=0.20
yfinance>=0.2.28
pandas-market-calendars>=4.3
streamlit>=1.32
pydantic>=2.5
keyring>=24.3
pytest>=8.1
python-dotenv>=1.0
numpy>=1.26
pandas>=2.2
```

Feature schema version constant should be:

```text
FEATURE_SCHEMA_VERSION = "features_v01"
```
