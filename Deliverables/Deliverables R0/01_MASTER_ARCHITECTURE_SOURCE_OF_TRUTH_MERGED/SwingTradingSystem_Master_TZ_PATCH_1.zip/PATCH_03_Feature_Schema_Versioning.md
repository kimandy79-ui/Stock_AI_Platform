# Patch 03 — Feature Schema Versioning

## Problem
`MAX(feature_schema_version)` on strings can fail:
`features_v9 > features_v10` lexicographically.

## V1 decision
Use zero-padded version names.

Required format:

```text
features_v01
features_v02
...
features_v10
```

## Update required
Set default config:

```text
FEATURE_SCHEMA_VERSION = "features_v01"
```

## Future V2
Use `feature_schema_registry` with integer `version_rank`.
