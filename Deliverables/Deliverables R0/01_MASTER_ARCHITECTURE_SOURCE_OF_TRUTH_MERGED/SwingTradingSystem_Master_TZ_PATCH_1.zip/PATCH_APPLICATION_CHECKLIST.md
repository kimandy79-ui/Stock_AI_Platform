# Patch Application Checklist

Apply before Module 03 Schema Manager finalization:
- Patch 01 entry_price_sim schema fields
- Patch 03 zero-padded feature schema version
- Patch 06 raw/diversified schema fields
- Patch 08 simulation fields
- Patch 10 selected proposals view

Apply before Module 11 Feature Engine:
- Patch 03 feature schema version
- Patch 05 avg dollar volume formula

Apply before Module 14 Step4:
- Patch 02 entry proxy for stop/target

Apply before Module 15 Step5:
- Patch 04 diversity logic
- Patch 06 raw/diversified schema
- Patch 07 Step5 logic
- Patch 09 UI behavior later

Apply before Module 16 Outcome Queue:
- Patch 01 entry_price_sim
- Patch 07 outcome queue rule
- Patch 08 simulation list membership

Modules 01–04 can begin immediately while this patch is applied.
