# Patch 06 — Raw vs Diversified Ranking

## Requirement
Always calculate both:
1. raw ranking without diversification;
2. diversified ranking after diversification logic.

UI checkbox controls display only.

## Schema changes

### step5_proposals
Add:

```sql
ALTER TABLE step5_proposals ADD COLUMN raw_rank INTEGER;
ALTER TABLE step5_proposals ADD COLUMN diversified_rank INTEGER;
ALTER TABLE step5_proposals ADD COLUMN in_raw_top_n BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE step5_proposals ADD COLUMN in_diversified_top_n BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE step5_proposals ADD COLUMN diversification_applied BOOLEAN NOT NULL DEFAULT TRUE;
```

Do not add `diversity_rejection_reason`.
Use existing `rejection_reason`.

### sim_step5_proposals
Add same fields:

```sql
ALTER TABLE sim_step5_proposals ADD COLUMN raw_rank INTEGER;
ALTER TABLE sim_step5_proposals ADD COLUMN diversified_rank INTEGER;
ALTER TABLE sim_step5_proposals ADD COLUMN in_raw_top_n BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE sim_step5_proposals ADD COLUMN in_diversified_top_n BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE sim_step5_proposals ADD COLUMN diversification_applied BOOLEAN NOT NULL DEFAULT TRUE;
```

## Indexes

```sql
CREATE INDEX IF NOT EXISTS idx_step5_run_raw_rank
    ON step5_proposals(run_id, signal_date, raw_rank);

CREATE INDEX IF NOT EXISTS idx_step5_run_div_rank
    ON step5_proposals(run_id, signal_date, diversified_rank);
```
