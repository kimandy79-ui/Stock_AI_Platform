# Patch 05 — Avg Dollar Volume and volume_adj

## Avg dollar volume

Replace:

```text
mean(close_adj * volume_raw)
```

with:

```text
avg_dollar_volume_20d = mean(close_raw * volume_raw over prior 20 trading days)
```

Reason:
Liquidity should reflect actual traded dollar value, not split-adjusted historical price.

## volume_adj

V1 decision:
`volume_adj` is reserved and not used in feature formulas.

Preferred:
- keep column only if already in schema;
- document as reserved;
- all V1 volume features use `volume_raw`.

Future V2 may remove or define volume adjustment explicitly.
