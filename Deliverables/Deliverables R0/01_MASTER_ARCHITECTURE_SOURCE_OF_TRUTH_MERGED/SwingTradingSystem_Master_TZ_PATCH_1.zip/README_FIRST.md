# SwingTradingSystem Master TZ — PATCH 1

Purpose:
This patch updates `SwingTradingSystem_Master_TZ_v1_FULL` before coding advances beyond Modules 01–04.

Patch includes:
1. Entry price / slippage clarification
2. Step 4 stop/target entry proxy clarification
3. Feature schema version zero-padding rule
4. Step 5 hard-cap / soft-penalty clarification
5. Avg dollar volume formula cleanup
6. volume_adj V1 handling clarification
7. Raw vs diversified ranking change request
8. Outcome queue update for raw/diversified Top 20
9. Simulation fields for raw vs diversified comparison
10. UI checkbox behavior

This patch does not reopen architecture.
Modules 01–04 can start coding while this patch is applied.
