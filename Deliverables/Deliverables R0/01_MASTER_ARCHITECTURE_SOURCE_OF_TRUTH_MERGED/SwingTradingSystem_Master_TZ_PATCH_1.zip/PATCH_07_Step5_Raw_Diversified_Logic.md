# Patch 07 — Step 5 Raw and Diversified Logic

## Raw ranking

Sort candidates by:
1. proposal_score_raw DESC
2. estimated_rr DESC
3. ticker ASC

Assign:
`raw_rank`.

Mark:
`in_raw_top_n = TRUE` if `raw_rank <= top_n`.

## Diversified ranking

Process candidates in raw_rank order.

If hard cap enabled:
- reject candidates exceeding sector or industry cap;
- keep raw_rank;
- set diversified_rank = NULL;
- set rejection_reason.

If accepted:
- assign next diversified_rank;
- mark `in_diversified_top_n = TRUE` if diversified_rank <= top_n.

## Outcome queue rule

Create outcome tracking tasks for candidates where:

```text
in_raw_top_n = TRUE
OR
in_diversified_top_n = TRUE
```

This allows feedback comparison between raw and diversified lists.
