# Patch 04 — Diversity Hard Cap / Soft Penalty Interaction

## Final rule

If `hard_cap_enabled = true`:
- candidates exceeding sector or industry cap are rejected;
- rejected candidates do not receive soft penalty;
- rejected candidates have `diversified_rank = NULL`;
- rejection reason is stored in `rejection_reason`.

If `hard_cap_enabled = false`:
- no hard rejection;
- soft penalties apply;
- all candidates may receive diversified_rank after score adjustment.

No double punishment.
