# Patch 01 — Entry Price and Slippage

## Problem
`entry_price_raw` was ambiguous. It could mean either:
- raw next-day open with no slippage; or
- simulated slippage-adjusted entry.

## Decision
Store both.

## Schema changes

### signal_outcomes
Add:

```sql
ALTER TABLE signal_outcomes ADD COLUMN entry_price_sim DOUBLE;
```

### sim_signal_outcomes
Add:

```sql
ALTER TABLE sim_signal_outcomes ADD COLUMN entry_price_sim DOUBLE;
```

## Definitions

`entry_price_raw = next trading day open_raw`

`entry_price_sim = open_raw * (1 + slippage_bps / 10000)`

For long-only V1.

## Return calculations
Use `entry_price_sim` for:
- return_5bd_pct
- return_10bd_pct
- return_20bd_pct
- return_40bd_pct
- MFE
- MAE
- realized R-multiple

Keep `entry_price_raw` for audit/execution reference.
