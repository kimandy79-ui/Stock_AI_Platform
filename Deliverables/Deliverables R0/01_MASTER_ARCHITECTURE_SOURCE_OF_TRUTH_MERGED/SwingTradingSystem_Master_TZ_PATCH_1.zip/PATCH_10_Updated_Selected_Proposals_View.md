# Patch 10 — selected_proposals_current View

Replace previous selected view with diversified-default version:

```sql
CREATE OR REPLACE VIEW selected_proposals_current AS
SELECT *
FROM step5_proposals
WHERE in_diversified_top_n = TRUE;
```

Meaning:
The default selected list is diversified.

Raw list is still accessible by querying `in_raw_top_n = TRUE`.
