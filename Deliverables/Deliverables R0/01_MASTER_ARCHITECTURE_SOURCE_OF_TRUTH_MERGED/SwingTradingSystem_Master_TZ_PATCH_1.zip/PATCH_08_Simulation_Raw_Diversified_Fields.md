# Patch 08 — Simulation Raw vs Diversified Metrics

## sim_signal_outcomes
Add:

```sql
ALTER TABLE sim_signal_outcomes ADD COLUMN list_membership VARCHAR;
```

Values:
- raw_only
- diversified_only
- both

## sim_config_comparisons
Add:

```sql
ALTER TABLE sim_config_comparisons ADD COLUMN list_type VARCHAR NOT NULL DEFAULT 'diversified';
```

Values:
- raw
- diversified

Recommended unique key logic:
`sim_run_id + config_id + horizon_bd + list_type`

## Purpose
Allows simulation comparison:

| List | Expectancy | Drawdown |
|---|---:|---:|
| raw | higher/lower | higher/lower |
| diversified | higher/lower | higher/lower |
