# Patch 09 — UI Diversified Checkbox

## Daily Proposals tab

Add checkbox:

```text
Show diversified shortlist
```

Default:
checked = TRUE.

Persist in Streamlit session state:

```python
st.session_state["show_diversified"]
```

## If checked

Query:

```sql
SELECT *
FROM step5_proposals
WHERE run_id = :run_id
  AND in_diversified_top_n = TRUE
ORDER BY diversified_rank ASC
LIMIT 20;
```

## If unchecked

Query:

```sql
SELECT *
FROM step5_proposals
WHERE run_id = :run_id
  AND in_raw_top_n = TRUE
ORDER BY raw_rank ASC
LIMIT 20;
```

## Table columns

Recommended order:
- Raw Rank
- Div Rank
- Ticker
- Strategy
- Setup Type
- Raw Score
- Final Score
- Est. RR
- Sector
- Industry
- Div. Reason
- Explanation

## Visual indicator
Highlight rows where:

```text
in_raw_top_n != in_diversified_top_n
```
