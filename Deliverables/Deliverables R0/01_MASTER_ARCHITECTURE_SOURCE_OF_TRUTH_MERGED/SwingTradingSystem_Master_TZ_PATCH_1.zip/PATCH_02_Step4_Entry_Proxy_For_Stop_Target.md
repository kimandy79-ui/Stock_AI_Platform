# Patch 02 — Step 4 Entry Proxy for Stop / Target

## Problem
Step 4 runs after market close on signal_date. It cannot know next trading day's open.

## Decision
Use signal_date `close_raw` as entry proxy for Step 4 stop/target estimates.

## Rule

At Step 4:

```text
entry_proxy_raw = close_raw on signal_date
```

Stop formula:

```text
stop_price_raw = min(recent_20d_low_raw, entry_proxy_raw - 1.5 * atr14_raw_equivalent)
```

Target formula:

```text
target_price_raw = entry_proxy_raw + target_R * (entry_proxy_raw - stop_price_raw)
```

Actual next-day entry is recorded later by outcome tracking.

## Gap warning
If actual next-day open differs from `entry_proxy_raw` by more than 5%, log a warning but do not recompute the original mechanical signal.
