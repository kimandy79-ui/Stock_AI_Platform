# Debug Mode Presets

## Fast Smoke Test
20 tickers, 5 trading days, full pipeline.

## Indicator Validation
10 tickers, 90 trading days, Step2 only.

## Pipeline Sanity
100 tickers, 30 trading days, Step1-Step5.

## Config Tuning Test
500 tickers, 6 months, Step3-Step5.
