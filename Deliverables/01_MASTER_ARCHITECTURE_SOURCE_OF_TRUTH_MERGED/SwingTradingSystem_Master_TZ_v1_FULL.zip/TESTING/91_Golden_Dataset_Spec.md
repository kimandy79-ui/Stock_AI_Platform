# Golden Dataset Spec

Default:
- tickers: AAPL, MSFT, NVDA, JPM, XOM, XLK, XLF, SPY, QQQ, ^VIX
- range: 2024-01-01 to 2024-06-30
- strategy: normal_v1

Expected outputs are stored after first validated run.
Future changes compare against these unless feature schema version changes.
