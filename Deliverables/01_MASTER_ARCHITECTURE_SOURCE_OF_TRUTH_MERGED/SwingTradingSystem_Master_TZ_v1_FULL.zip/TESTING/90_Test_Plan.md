# Test Plan

## Unit tests
- schema creation idempotent
- RVOL formula
- RSI formula
- ATR formula
- EMA alignment
- market regime priority
- diversity hard cap
- stop/target formula
- outcome queue missing-day behavior

## Integration tests
- 20 ticker debug pipeline
- benchmark ingestion before features
- Step3 -> Step5
- outcome queue
- simulation attach read-only

## Regression tests
Golden dataset must produce identical outputs with same DB/config.
