# Dashboard Tab Specs

## Daily Proposals
Columns:
rank, ticker, strategy, proposal_score_final, setup_type, estimated_rr, sector, industry, earnings risk, explanation.

## Signal Explorer
Filters:
date range, ticker, strategy, setup_type, score range.

## Strategy Performance
Metrics:
expectancy, win rate, avg win, avg loss, profit factor, drawdown.

## Outcome Tracking
Show 5/10/20/40bd returns, MFE, MAE, unresolved outcomes.

## Config Manager
View, clone, edit, activate, compare configs.

## Pipeline Health
pipeline_runs, repair_queue, provider warnings, failed tickers.

## Simulation Lab
date range, mode, config selection, run simulation, compare results.

## AI Review
select tickers or simulation, download package, copy prompt, send to AI.

## Debug Mode
sample count, watchlist, preset, step selection, run debug.
