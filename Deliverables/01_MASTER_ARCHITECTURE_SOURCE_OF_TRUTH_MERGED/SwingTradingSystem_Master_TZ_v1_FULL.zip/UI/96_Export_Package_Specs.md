# Export Package Specs

## Ticker review ZIP
Files:
- metadata.json
- prices.csv
- features.csv
- step3.csv
- step4.csv
- step5.csv
- explanation.txt

## Simulation review ZIP
Files:
- configs.json
- performance_metrics.csv
- score_buckets.csv
- setup_performance.csv
- regime_performance.csv
- drawdowns.csv
- unresolved_outcomes.csv
