# Module 07: Benchmark / Sector ETF Loader

## Purpose
Load SPY, QQQ, ^VIX and sector ETFs before feature calculation.

## Symbols
- SPY: benchmark ETF
- QQQ: benchmark ETF
- ^VIX: index benchmark
- XLK, XLF, XLV, XLY, XLP, XLC, XLI, XLE, XLB, XLU, XLRE: sector ETFs

## VIX handling
Use Yahoo symbol `^VIX`.
Store:
- close_raw = close_adj = VIX close
- open/high/low if available
- volume_raw = NULL or 0
- symbol_type = index
- exclude from screening

## ETF handling
Sector ETFs are symbol_type = benchmark or etf and excluded from screening.
They are used only for market regime and sector_relative_strength.
