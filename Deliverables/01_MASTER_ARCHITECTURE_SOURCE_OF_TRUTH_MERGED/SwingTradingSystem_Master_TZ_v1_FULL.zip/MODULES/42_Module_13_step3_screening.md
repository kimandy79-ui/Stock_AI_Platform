# Module 13: Step3 Screening

## Purpose
Apply hard filters and soft scoring.

## Inputs
- daily_features_current
- ticker_master
- strategy_config

## Outputs
- step3_candidates

## Hard filters
- feature_ready TRUE
- symbol_type stock
- close_raw >= min_price
- avg_dollar_volume_20d >= min_avg_dollar_volume_20d
- rvol20 >= min_rvol
- data quality OK

## Scoring
Use FORMULAS/61_Scoring_Formulas_Step3.md.

## Tests
- hard filter pass/fail
- score reproducibility
- missing sector RS handled as neutral/no boost
