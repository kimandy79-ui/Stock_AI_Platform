# Module 14: Step4 Setup Analysis

## Purpose
Classify setup type and estimate RR.

## Inputs
- step3_candidates
- daily_features_current
- daily_prices

## Outputs
- step4_analysis

## Rules
Use FORMULAS/62_Scoring_Formulas_Step4.md.

## Tests
- stop below entry
- target above entry
- estimated_rr finite and positive
- setup_type enum valid
