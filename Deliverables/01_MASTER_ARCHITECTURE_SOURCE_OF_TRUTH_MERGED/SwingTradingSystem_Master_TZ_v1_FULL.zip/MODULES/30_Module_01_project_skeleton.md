# Module 01: Project Skeleton

## Purpose
Implement the `project_skeleton` component according to the Master TZ.

## Inputs
- db_manager where applicable
- config where applicable
- run_id where applicable

## Outputs
- ServiceResult
- writes to defined tables where applicable

## Rules
- no look-ahead
- config-driven
- no direct unrelated module logic
- tests required

## Testing
Unit tests and integration hooks must be provided.
