# SwingTradingSystem Master TZ v1 FULL

Status: Full implementation-grade specification for AI-assisted Python development.

This package is based on:
- architecture review cycle V1.5 → V1.7.1;
- Claude final green-light;
- accepted research-grade V1 limitations;
- final decision to use DuckDB, Polars-first, Streamlit local dashboard, YahooProvider V1 via provider abstraction.

## How to use this package

Do not give the entire package to an AI for coding at once.

Use module-specific docs:
- Architecture docs for context
- Relevant schema docs
- Relevant formula/config docs
- Relevant module spec
- Relevant prompt in `PROMPTS/99_Module_Prompts/`

## Folder structure

- `SCHEMA/` — DuckDB schemas, enums, views, indexes
- `CONFIG/` — base/strategy configs and config reference
- `FORMULAS/` — feature, scoring, outcome formulas
- `MODULES/` — module-by-module implementation specs
- `PIPELINE/` — orchestrator, interfaces, error handling, calendar
- `SIMULATION/` — simulation and walk-forward specs
- `TESTING/` — tests, golden dataset, debug presets
- `UI/` — Streamlit tabs and export specs
- `PROMPTS/` — AI coding prompts

## Build order

1. Project skeleton
2. DuckDB manager
3. Schema manager
4. Provider interface
5. YahooProvider
6. Universe snapshot engine
7. Benchmark / sector ETF loader
8. Daily price ingestion
9. Data validator
10. Mutation detector
11. Feature engine
12. Market regime engine
13. Step 3 screening
14. Step 4 setup analysis
15. Step 5 proposal engine
16. Outcome queue
17. Simulation engine
18. Export package engine
19. AI review engine
20. Pipeline orchestrator
21. Streamlit dashboard
22. Debug mode
