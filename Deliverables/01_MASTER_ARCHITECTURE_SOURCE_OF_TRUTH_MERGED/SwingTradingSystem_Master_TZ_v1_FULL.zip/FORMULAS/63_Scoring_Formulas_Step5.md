# Step5 Proposal Scoring

## Raw proposal score
`proposal_score_raw = 0.40*setup_score + 0.25*screening_score + 0.20*estimated_rr_score + 0.15*timing_score`

## RR score
- 100 if estimated_rr >= 3.0
- 80 if 2.2 <= estimated_rr < 3.0
- 60 if 1.8 <= estimated_rr < 2.2
- 0 if < 1.8

## Diversity
If hard cap enabled:
- reject if sector count >= sector_max_positions
- reject if industry count >= industry_max_positions
- do not apply soft penalty to rejected candidate

If hard cap disabled:
- apply sector_penalty_factor and industry_penalty_factor

## Final proposal score
If not rejected:
`proposal_score_final = proposal_score_raw * sector_penalty * industry_penalty`
