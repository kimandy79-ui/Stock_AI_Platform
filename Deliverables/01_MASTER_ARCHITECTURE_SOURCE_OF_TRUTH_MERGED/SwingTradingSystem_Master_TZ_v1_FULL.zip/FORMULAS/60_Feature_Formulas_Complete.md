# Feature Formulas Complete

All formulas use rows with date <= feature_cutoff_date.

## EMA
EMA20/50/200 on close_adj.

## EMA Alignment Score
- 100 if EMA20 > EMA50 > EMA200
- 50 if close_adj > EMA200 but full alignment is false
- 0 otherwise

## RSI14
Wilder RSI14 on close_adj.

## ROC20
`roc20 = close_adj_t / close_adj_{t-20} - 1`

## ATR14
Wilder ATR using adjusted OHLC.

## ATR%
`atr_pct = atr14 / close_adj_t`

## RVOL20
`rvol20 = volume_raw_t / mean(volume_raw over t-20 to t-1)`

## Avg volume 20d
Mean of volume_raw over prior 20 trading days.

## Avg dollar volume 20d
`mean(close_adj * volume_raw over prior 20 trading days)`

## Distance from 52W high
`close_adj_t / max(close_adj over 252 trading days ending at t) - 1`

## Pullback from recent high
`close_adj_t / max(close_adj over 20 trading days ending at t) - 1`

## Breakout proximity
`(close_adj_t - rolling_20d_high_t) / atr14_t`

`rolling_20d_high_t = max(close_adj over 20 trading days ending at feature_cutoff_date)`

## Consolidation score
`atr_contraction = 1 - min(ATR14_current / mean(ATR14 over prior 60 trading days), 1)`

`range_contraction = 1 - min(mean(high_adj - low_adj over prior 10 trading days) / mean(high_adj - low_adj over prior 60 trading days), 1)`

`volume_contraction = 1 - min(mean(volume_raw over prior 10 trading days) / mean(volume_raw over prior 60 trading days), 1)`

`consolidation_score = 100 * (0.4*atr_contraction + 0.4*range_contraction + 0.2*volume_contraction)`

Clip to 0-100.

## Sector relative strength
`ticker_20d_return_adj - sector_etf_20d_return_adj`

If sector is unmapped, value NULL and no boost applied.
