# Outcome Calculation Rules

## Entry
Entry date = next US trading day after signal_date.
Entry price = open_raw adjusted for slippage.

For long:
`entry_price = open_raw * (1 + slippage_bps / 10000)`

## Horizon returns
Use adjusted close:
`return_Nbd_pct = close_adj_Nbd / entry_price_raw - 1`

## MFE
`mfe_40bd_pct = max(high_adj over entry_date to 40bd eval date) / entry_price_raw - 1`

## MAE
`mae_40bd_pct = min(low_adj over entry_date to 40bd eval date) / entry_price_raw - 1`

## Realized R multiple
`realized_r_multiple = (exit_price_raw_or_adj_equivalent - entry_price_raw) / (entry_price_raw - stop_price_raw)`

V1 uses adjusted close converted to raw-equivalent only if necessary. For simplicity, realized R is primarily used directionally.

## Missing eval candle
Repair first. If unresolved after 3 business days, mark UNRESOLVABLE and exclude from aggregate metrics.
