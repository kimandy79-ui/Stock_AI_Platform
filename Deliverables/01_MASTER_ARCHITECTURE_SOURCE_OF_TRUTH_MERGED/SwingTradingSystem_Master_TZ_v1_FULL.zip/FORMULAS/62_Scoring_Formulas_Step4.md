# Step4 Setup Analysis Formulas

## setup_type enum
- trend_pullback
- breakout
- volatility_squeeze
- trend_resume
- high_tight_flag
- unknown

## Setup type rules
trend_pullback:
- close_adj > EMA200
- pullback_from_recent_high_pct between -12% and -3%
- EMA20 > EMA50

breakout:
- breakout_proximity between -0.5 and 0.5
- rvol20 >= strategy min_rvol

volatility_squeeze:
- consolidation_score >= 70
- ATR contraction positive

trend_resume:
- close_adj crosses back above EMA20 after pullback

high_tight_flag:
- strong ROC20 > 15%
- consolidation_score >= 60

## Stop price
V1 formula:
`stop_price_raw = min(recent_20d_low_raw, entry_price_raw - 1.5 * atr14_raw_equivalent)`

If adjusted ATR only is available:
`atr14_raw_equivalent = atr14 * (close_raw / close_adj)`

## Target price
V1 formula:
`target_price_raw = entry_price_raw + target_R * (entry_price_raw - stop_price_raw)`

Defaults:
- aggressive target_R = 1.8
- normal target_R = 2.2
- conservative target_R = 2.8

## Estimated RR
`estimated_rr = (target_price_raw - entry_price_raw) / (entry_price_raw - stop_price_raw)`

## Step4 component score
setup_quality = average of breakout_quality, squeeze_score, timing_score, confirmation_score.

## Earnings penalty
If days_to_earnings_bd <= avoid_within_bd:
penalty = earnings_penalty_max * (1 - days_to_earnings_bd / avoid_within_bd)

Penalty is score points, negative number.
