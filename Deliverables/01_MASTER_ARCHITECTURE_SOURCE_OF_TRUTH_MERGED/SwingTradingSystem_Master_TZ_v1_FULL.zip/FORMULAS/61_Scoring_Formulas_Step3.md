# Step3 Screening Scoring Formulas

## Hard filters
Fail if:
- feature_ready != TRUE
- symbol_type != stock
- close_raw < min_price
- avg_dollar_volume_20d < min_avg_dollar_volume_20d
- rvol20 < min_rvol
- data_quality_status != ok

## Normalization helpers
Clamp all sub-scores to 0-100.

## Trend score
Inputs:
- ema_alignment_score: 50%
- distance_to_ema50_pct: 25%
- close above EMA200: 25%

Rules:
- ema_alignment_score already 0/50/100.
- distance_to_ema50 ideal range: -3% to +8%.
  - score 100 if within range.
  - score declines linearly outside range.
- close above EMA200: 100 if true else 0.

## Momentum score
Inputs:
- RSI14: 40%
- ROC20: 30%
- sector_relative_strength: 30%

RSI score:
- 100 if 50 <= RSI <= 65
- 70 if 45 <= RSI < 50 or 65 < RSI <= 70
- 30 otherwise

ROC20 score:
- 100 if ROC20 > 0.08
- 70 if 0.03 <= ROC20 <= 0.08
- 30 if 0 <= ROC20 < 0.03
- 0 if ROC20 < 0

Sector RS score:
- 100 if > 0.05
- 70 if 0 to 0.05
- 30 if -0.05 to 0
- 0 if < -0.05
- neutral 50 if NULL

## Setup score
Inputs:
- consolidation_score: 40%
- breakout_proximity: 30%
- pullback_from_recent_high_pct: 30%

Breakout proximity score:
- 100 if -1 <= breakout_proximity <= 0.5
- 70 if -2 <= breakout_proximity < -1
- 30 if breakout_proximity < -2
- 20 if breakout_proximity > 1.5

Pullback score:
- 100 if -0.12 <= pullback <= -0.03
- 70 if -0.20 <= pullback < -0.12
- 30 otherwise

## Volume score
Inputs:
- rvol20: 60%
- avg_dollar_volume_20d: 40%

RVOL score:
- 100 if rvol20 >= 2.0
- 70 if 1.5 <= rvol20 < 2.0
- 40 if 1.2 <= rvol20 < 1.5
- 0 if below 1.2

## Market score
- bull: 100
- neutral: 60
- bear: 20
- high_risk: 0
- extreme_risk: 0

## Final screening score
`screening_score = 0.30*trend + 0.25*momentum + 0.20*setup + 0.15*volume + 0.10*market`
