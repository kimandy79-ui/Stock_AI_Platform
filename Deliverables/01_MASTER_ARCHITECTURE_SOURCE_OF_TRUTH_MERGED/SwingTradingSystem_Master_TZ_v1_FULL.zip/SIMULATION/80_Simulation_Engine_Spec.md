# Simulation Engine Spec

## Storage
Writes only to simulation.duckdb.

## Read access
Attach prod read-only:
`ATTACH 'data/duckdb/prod.duckdb' AS prod (READ_ONLY);`

## Simulation flow
For each sim date:
1. load universe snapshot as of date
2. load daily_features_current where feature_cutoff_date <= sim date
3. run Step3/4/5 into sim tables
4. create simulated outcomes
5. calculate outcomes once eval dates available

## Feature recalculation
V1 uses precomputed prod features.
If feature schema changes, rebuild prod features first or run feature-specific simulation version.
