# Walk-Forward Protocol

## Default
Expanding window.

Initial train:
12 months minimum.

Test fold:
calendar quarter.

## Config selection
Calculate metrics on train window.
Select config maximizing expectancy subject to:
- resolved_outcomes_pct >= 0.85
- max_drawdown_pct <= 25

## Cross-fold outcomes
If signal outcome extends beyond test fold:
- store it
- cross_fold_outcome = TRUE
- exclude from fold metrics
