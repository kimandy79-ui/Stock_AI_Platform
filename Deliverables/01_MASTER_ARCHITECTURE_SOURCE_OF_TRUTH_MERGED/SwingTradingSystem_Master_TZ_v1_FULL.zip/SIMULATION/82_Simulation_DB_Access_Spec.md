# Simulation DB Access

Simulation session:
1. connect to simulation.duckdb
2. ATTACH prod.duckdb read-only
3. query prod.daily_prices / prod.daily_features_current
4. write only sim_* tables

Never write to prod from simulation session.
