# Config Reference Guide

## universe
Controls tradability filters.

## features
Controls feature lookbacks and schema version.

## screening
Controls Step3 hard/soft pass thresholds.

## scoring_weights
Must sum to 1.0.

## market_regime
VIX thresholds used by Market Regime Engine.

## diversification
Hard cap enabled by default.
If hard cap rejects a candidate, soft penalty is not applied.

## sector_etf_mapping
Static mapping for sector relative strength.

## simulation
Entry, returns, slippage, horizons, and fold acceptance thresholds.

## macro_event_risk
Event types and penalty.

## earnings
Earnings avoidance / penalty rules.
