# Prompt 05: yahoo_provider

Use the AI Coding Prompt Template.

Implement module:
yahoo_provider

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/34_Module_05_yahoo_provider.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
