# Prompt 02: duckdb_manager

Use the AI Coding Prompt Template.

Implement module:
duckdb_manager

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/31_Module_02_duckdb_manager.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
