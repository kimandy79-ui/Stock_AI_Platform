# Prompt 18: export_package_engine

Use the AI Coding Prompt Template.

Implement module:
export_package_engine

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/47_Module_18_export_package_engine.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
