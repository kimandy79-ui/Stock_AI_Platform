# Prompt 14: step4_setup_analysis

Use the AI Coding Prompt Template.

Implement module:
step4_setup_analysis

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/43_Module_14_step4_setup_analysis.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
