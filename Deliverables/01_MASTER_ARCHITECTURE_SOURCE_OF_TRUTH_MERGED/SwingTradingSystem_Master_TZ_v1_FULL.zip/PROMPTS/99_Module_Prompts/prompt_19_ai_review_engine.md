# Prompt 19: ai_review_engine

Use the AI Coding Prompt Template.

Implement module:
ai_review_engine

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/48_Module_19_ai_review_engine.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
