# Prompt 06: universe_snapshot_engine

Use the AI Coding Prompt Template.

Implement module:
universe_snapshot_engine

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/35_Module_06_universe_snapshot_engine.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
