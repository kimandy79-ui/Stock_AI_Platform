# Prompt 08: daily_price_ingestion

Use the AI Coding Prompt Template.

Implement module:
daily_price_ingestion

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/37_Module_08_daily_price_ingestion.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
