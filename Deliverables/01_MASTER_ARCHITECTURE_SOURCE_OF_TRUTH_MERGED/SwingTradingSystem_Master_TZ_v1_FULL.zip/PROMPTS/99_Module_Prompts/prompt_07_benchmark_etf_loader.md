# Prompt 07: benchmark_etf_loader

Use the AI Coding Prompt Template.

Implement module:
benchmark_etf_loader

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/36_Module_07_benchmark_etf_loader.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
