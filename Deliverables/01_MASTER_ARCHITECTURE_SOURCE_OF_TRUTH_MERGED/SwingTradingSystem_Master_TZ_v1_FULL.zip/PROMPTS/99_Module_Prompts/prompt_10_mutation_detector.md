# Prompt 10: mutation_detector

Use the AI Coding Prompt Template.

Implement module:
mutation_detector

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/39_Module_10_mutation_detector.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
