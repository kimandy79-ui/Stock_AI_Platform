# Prompt 12: market_regime_engine

Use the AI Coding Prompt Template.

Implement module:
market_regime_engine

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/41_Module_12_market_regime_engine.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
