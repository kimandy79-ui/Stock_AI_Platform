# Prompt 01: project_skeleton

Use the AI Coding Prompt Template.

Implement module:
project_skeleton

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/30_Module_01_project_skeleton.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
