# Prompt 11: feature_engine

Use the AI Coding Prompt Template.

Implement module:
feature_engine

Relevant docs:
- SCHEMA/*
- CONFIG/*
- FORMULAS/* if applicable
- MODULES/40_Module_11_feature_engine.md if available
- PIPELINE/71_Module_Interface_Contracts.md
- TESTING/90_Test_Plan.md

Requirements:
- Implement only this module.
- Add pytest tests.
- Return file list and brief explanation.
