# Project Scope and Constraints

## Objective
Build a local US daily swing trading research system that:
- downloads daily EOD data;
- calculates reusable features;
- screens, analyzes and ranks stock candidates;
- proposes Top N stock lists per strategy;
- tracks forward outcomes;
- supports walk-forward simulation;
- supports AI review without contaminating mechanical performance attribution.

## Primary KPI
Expectancy > hit rate.

## Strategies
- aggressive
- normal
- conservative

## Platform
- Windows local PC
- Python
- DuckDB
- Polars-first processing
- Streamlit local dashboard

## Research-grade V1 limitations
Accepted:
- YahooProvider is V1 source, no SLA.
- Monthly universe snapshots reduce but do not eliminate survivorship bias.
- No intraday execution.
- No broker integration.
- No auto-trading.
- Streamlit is local single-user UI.
- Historical depth may be limited; warm-up and single-regime caveats must be displayed.

## Non-negotiable guardrails
- No look-ahead bias.
- No raw/adjusted mixing.
- No production/debug/simulation contamination.
- No config overwrites.
- No AI attribution contamination.
- No direct provider calls outside provider layer.
