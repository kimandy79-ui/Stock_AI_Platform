# Index and Constraint Reference

## Performance indexes

Required:
- daily_prices(ticker, date)
- daily_features(ticker, feature_date)
- step3_candidates(run_id, signal_date)
- step5_proposals(run_id, signal_date, selected_flag)
- signal_outcomes(strategy_config_id, signal_date)
- outcome_tracking_queue(status, eval_date)
- data_repair_queue(status, repair_date)

## Constraint philosophy
DuckDB supports constraints but this system also validates at service layer.

Hard constraints:
- Primary keys for all fact tables
- Not null for IDs, dates, run IDs, statuses
- All enum values validated by Pydantic before insert

## Important uniqueness
- one daily price per ticker/date
- one feature row per ticker/feature_date/feature_schema_version
- one queue task per proposal/horizon_bd
