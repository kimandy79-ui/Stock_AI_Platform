-- Simulation DuckDB Schema v1 FULL

CREATE TABLE IF NOT EXISTS sim_runs (
    sim_run_id VARCHAR PRIMARY KEY,
    sim_name VARCHAR,
    mode VARCHAR NOT NULL, -- research, walk_forward, config_comparison
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    created_at TIMESTAMP NOT NULL,
    config_ids JSON NOT NULL,
    status VARCHAR NOT NULL, -- pending, running, success, failed
    notes TEXT
);

CREATE TABLE IF NOT EXISTS sim_folds (
    fold_id VARCHAR PRIMARY KEY,
    sim_run_id VARCHAR NOT NULL,
    fold_number INTEGER NOT NULL,
    train_start DATE NOT NULL,
    train_end DATE NOT NULL,
    test_start DATE NOT NULL,
    test_end DATE NOT NULL,
    selected_config_id VARCHAR,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS sim_step3_candidates (
    candidate_id VARCHAR PRIMARY KEY,
    sim_run_id VARCHAR NOT NULL,
    fold_id VARCHAR,
    strategy_config_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    screening_score DOUBLE,
    passed_hard_filters BOOLEAN NOT NULL,
    hard_filter_fail_reasons JSON,
    soft_score_components JSON,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS sim_step4_analysis (
    analysis_id VARCHAR PRIMARY KEY,
    candidate_id VARCHAR NOT NULL,
    sim_run_id VARCHAR NOT NULL,
    fold_id VARCHAR,
    strategy_config_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    setup_type VARCHAR,
    setup_score DOUBLE,
    estimated_rr DOUBLE,
    stop_price_raw DOUBLE,
    target_price_raw DOUBLE,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS sim_step5_proposals (
    proposal_id VARCHAR PRIMARY KEY,
    sim_run_id VARCHAR NOT NULL,
    fold_id VARCHAR,
    strategy_config_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    proposal_score_raw DOUBLE,
    diversity_penalty DOUBLE,
    proposal_score_final DOUBLE,
    rank_position INTEGER,
    selected_top_n BOOLEAN NOT NULL,
    rejection_reason VARCHAR,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS sim_signal_outcomes (
    outcome_id VARCHAR PRIMARY KEY,
    sim_run_id VARCHAR NOT NULL,
    fold_id VARCHAR,
    proposal_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    strategy_config_id VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    entry_date DATE NOT NULL,
    entry_price_raw DOUBLE,
    return_5bd_pct DOUBLE,
    return_10bd_pct DOUBLE,
    return_20bd_pct DOUBLE,
    return_40bd_pct DOUBLE,
    mfe_40bd_pct DOUBLE,
    mae_40bd_pct DOUBLE,
    realized_r_multiple DOUBLE,
    cross_fold_outcome BOOLEAN NOT NULL DEFAULT FALSE,
    outcome_status VARCHAR NOT NULL,
    calculated_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sim_config_comparisons (
    comparison_id VARCHAR PRIMARY KEY,
    sim_run_id VARCHAR NOT NULL,
    config_id VARCHAR NOT NULL,
    horizon_bd INTEGER NOT NULL,
    expectancy DOUBLE,
    win_rate DOUBLE,
    avg_win DOUBLE,
    avg_loss DOUBLE,
    profit_factor DOUBLE,
    max_drawdown_pct DOUBLE,
    resolved_outcomes_pct DOUBLE,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS sim_ai_reviews (
    ai_review_id VARCHAR PRIMARY KEY,
    sim_run_id VARCHAR NOT NULL,
    provider VARCHAR NOT NULL,
    model VARCHAR NOT NULL,
    prompt_version VARCHAR NOT NULL,
    prompt_text TEXT NOT NULL,
    ai_response_text TEXT,
    human_action VARCHAR,
    created_at TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_sim_props_run_date ON sim_step5_proposals(sim_run_id, signal_date);
CREATE INDEX IF NOT EXISTS idx_sim_outcomes_config_date ON sim_signal_outcomes(strategy_config_id, signal_date);
