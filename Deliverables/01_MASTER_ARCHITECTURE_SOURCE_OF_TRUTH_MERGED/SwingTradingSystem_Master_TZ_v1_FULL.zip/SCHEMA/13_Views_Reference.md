# Views Reference

## daily_features_current

Purpose:
Prevent accidental duplicate joins across feature schema versions.

Preferred implementation uses a feature schema registry. V1 simple version:

```sql
CREATE OR REPLACE VIEW daily_features_current AS
SELECT *
FROM daily_features
WHERE feature_schema_version = (
    SELECT MAX(feature_schema_version) FROM daily_features
);
```

All application queries must use `daily_features_current` unless explicitly testing historical schema versions.

## selected_proposals_current

Recommended dashboard view:

```sql
CREATE OR REPLACE VIEW selected_proposals_current AS
SELECT *
FROM step5_proposals
WHERE selected_top_n = TRUE;
```
