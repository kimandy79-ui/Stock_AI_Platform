# Enum Values Reference

## data_quality_status
- ok
- warning
- suspect
- failed
- quarantined

## outcome_status
- pending
- complete
- partial
- unresolvable
- failed

## queue status
- pending
- processing
- done
- failed
- unresolvable

## market_regime
- bull
- neutral
- bear
- high_risk
- extreme_risk

## symbol_type
- stock
- etf
- benchmark
- index

## setup_type
- trend_pullback
- breakout
- volatility_squeeze
- trend_resume
- high_tight_flag
- unknown

## decision_source
- mechanical_only
- human_only
- ai_assisted

## human_action
- ignored
- accepted
- overrode
- deferred

## session
- pre_market
- post_market
- during_market
- unknown

## confidence
- high
- medium
- low

## review_type
- ticker_review
- simulation_review
- config_review

## execution action
- watch
- paper_trade
- skip
- real_trade

## run_status
- pending
- running
- success
- success_with_warnings
- failed
- cancelled
