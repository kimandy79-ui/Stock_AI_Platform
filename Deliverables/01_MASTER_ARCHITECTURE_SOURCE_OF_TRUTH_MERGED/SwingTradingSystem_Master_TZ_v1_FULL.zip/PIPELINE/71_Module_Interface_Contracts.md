# Module Interface Contracts

Each service returns:
- status: success / success_with_warnings / failed
- run_id
- rows_processed
- warnings
- errors
- output_table_names

Python recommended return dataclass:

```python
@dataclass
class ServiceResult:
    status: str
    run_id: str
    rows_processed: int = 0
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
```

All modules accept:
- db_manager
- run_id
- config
- date range or signal date
