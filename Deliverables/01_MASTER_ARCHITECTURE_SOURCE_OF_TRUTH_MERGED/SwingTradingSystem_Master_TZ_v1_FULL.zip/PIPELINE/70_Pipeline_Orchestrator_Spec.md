# Pipeline Orchestrator Spec

## run_id
Use UUID4 string.

## Lock
Use pipeline_locks table:
- acquire lock before run
- heartbeat during run
- release lock after success/failure

## Already-run check
Before scheduled/manual run:
check pipeline_runs where run_date = today and status in success/success_with_warnings.

If exists:
- block normal run
- allow force_rerun

## Step order
1. benchmark/sector ETF ingestion
2. stock universe ingestion
3. stock price ingestion
4. validation
5. mutation detection
6. feature calculation
7. Step3
8. Step4
9. Step5
10. outcome queue generation
11. due outcome processing
12. dashboard materialization
13. backup

## Partial failure
If a step fails:
- update pipeline_runs
- keep completed step state
- allow resume from failed step
