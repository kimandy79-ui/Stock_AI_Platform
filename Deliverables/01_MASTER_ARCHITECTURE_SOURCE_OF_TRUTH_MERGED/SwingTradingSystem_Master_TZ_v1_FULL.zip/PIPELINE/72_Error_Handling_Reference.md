# Error Handling Reference

## Warning
Continue:
- missing sector
- low confidence earnings
- small provider timeout count

## Recoverable failure
Continue degraded:
- some tickers failed download
- repair queue populated
- non-critical dashboard materialization failure

## Critical failure
Stop:
- DB connection failure
- schema mismatch
- invalid config
- feature calculation crash
- look-ahead validation failure

All critical failures write pipeline_runs.status = failed.
