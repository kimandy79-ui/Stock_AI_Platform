# Trading Calendar Spec

Use `pandas_market_calendars` with NYSE calendar.

All business day calculations use NYSE trading sessions.

Functions required:
- is_trading_day(date)
- previous_trading_day(date)
- next_trading_day(date)
- add_trading_days(date, n)
- trading_days_between(start, end)
