"""Phase 6 tests — Setup-mode funnel diagnostics (M20/M22).

Tests verify:
  - SetupModeFunnelDiagnosticsService writes the required metric rows
  - Metric names use setup names (breakout/pullback/trend_continuation/consolidation_base)
  - 'conservative_consolidation' never appears in metric names
  - All required Phase 6 diagnostic metrics are present
  - db_role validation
  - Empty pipeline data returns success (no metrics = warning)
  - read() helper returns structured rows
  - Old strategy-mode terms not in diagnostic output
  - Legacy FunnelDiagnosticsService alias resolves to setup-mode class
"""

from __future__ import annotations

import json
import uuid
from datetime import date, datetime
from pathlib import Path
from typing import Any

import duckdb
import pytest

from app.services.diagnostics.funnel_diagnostics import (
    SetupModeFunnelDiagnosticsService,
    FunnelDiagnosticsService,
    ACTIVE_SETUP_TYPES,
)
from app.utils.service_result import ServiceResult

SIG_DATE = date(2026, 6, 15)
RUN_ID = "test-run-001"

# --------------------------------------------------------------------------- #
# Minimal schema DDL needed for diagnostics tests
# --------------------------------------------------------------------------- #
_SCHEMA_DDL = """
CREATE TABLE IF NOT EXISTS step3_candidates (
    candidate_id VARCHAR PRIMARY KEY,
    run_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    eligibility_score DOUBLE,
    passed_eligibility BOOLEAN NOT NULL,
    routing_status VARCHAR NOT NULL,
    routing_fail_reason VARCHAR,
    eligibility_fail_reasons JSON,
    routed_setup_types JSON,
    feature_snapshot_json JSON,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS step4_analysis (
    analysis_id VARCHAR PRIMARY KEY,
    candidate_id VARCHAR NOT NULL,
    run_id VARCHAR NOT NULL,
    setup_config_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    setup_type VARCHAR NOT NULL,
    setup_score DOUBLE,
    setup_passed BOOLEAN NOT NULL,
    setup_reasons JSON,
    setup_fail_reason VARCHAR,
    entry_price_raw DOUBLE,
    stop_price_raw DOUBLE,
    target_price_raw DOUBLE,
    estimated_rr DOUBLE,
    target_is_structural BOOLEAN,
    stop_distance_pct DOUBLE,
    support_level DOUBLE,
    resistance_level DOUBLE,
    next_resistance_level DOUBLE,
    atr_pct DOUBLE,
    distance_to_ema20_pct DOUBLE,
    distance_to_ema50_pct DOUBLE,
    rvol DOUBLE,
    earnings_days INTEGER,
    market_regime VARCHAR,
    earnings_penalty DOUBLE,
    macro_penalty DOUBLE,
    explanation_json JSON,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS step5_proposals (
    proposal_id VARCHAR PRIMARY KEY,
    run_id VARCHAR NOT NULL,
    setup_config_id VARCHAR NOT NULL,
    ticker VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    setup_type VARCHAR NOT NULL,
    setup_score DOUBLE,
    risk_score DOUBLE,
    risk_label VARCHAR,
    risk_reasons JSON,
    disposition VARCHAR NOT NULL,
    entry_price_raw DOUBLE,
    stop_price_raw DOUBLE,
    target_price_raw DOUBLE,
    estimated_rr DOUBLE,
    target_is_structural BOOLEAN,
    support_level DOUBLE,
    resistance_level DOUBLE,
    next_resistance_level DOUBLE,
    earnings_days INTEGER,
    market_regime VARCHAR,
    proposal_score_raw DOUBLE,
    diversity_penalty DOUBLE,
    proposal_score_final DOUBLE,
    raw_rank INTEGER,
    diversified_rank INTEGER,
    in_raw_top_n BOOLEAN NOT NULL DEFAULT FALSE,
    in_diversified_top_n BOOLEAN NOT NULL DEFAULT FALSE,
    diversification_applied BOOLEAN NOT NULL DEFAULT TRUE,
    selected_top_n BOOLEAN NOT NULL DEFAULT FALSE,
    selected_flag BOOLEAN NOT NULL DEFAULT FALSE,
    ai_reviewed BOOLEAN NOT NULL DEFAULT FALSE,
    executed_flag BOOLEAN NOT NULL DEFAULT FALSE,
    rejection_reason VARCHAR,
    setup_reasons JSON,
    mechanical_explanation TEXT,
    sector_count_at_selection INTEGER,
    industry_count_at_selection INTEGER,
    created_at TIMESTAMP NOT NULL
);

CREATE TABLE IF NOT EXISTS pipeline_run_diagnostics (
    diag_id VARCHAR PRIMARY KEY,
    run_id VARCHAR NOT NULL,
    signal_date DATE NOT NULL,
    db_role VARCHAR NOT NULL,
    step_name VARCHAR NOT NULL,
    setup_type VARCHAR,
    metric_name VARCHAR NOT NULL,
    metric_value DOUBLE,
    reason VARCHAR,
    metadata_json JSON,
    created_at TIMESTAMP NOT NULL
);
"""


# --------------------------------------------------------------------------- #
# FakeDbManager backed by an in-process DuckDB
# --------------------------------------------------------------------------- #
class FakeDbManager:
    def __init__(self, path: str = ":memory:"):
        self._conn = duckdb.connect(path)
        self._conn.execute(_SCHEMA_DDL)

    def connect(self, db_role: str, read_only: bool = False):
        return _FakeConn(self._conn)

    def close(self):
        self._conn.close()


class _FakeConn:
    def __init__(self, conn):
        self._c = conn

    def execute(self, sql, params=None):
        if params is None:
            return self._c.execute(sql)
        return self._c.execute(sql, params)

    def close(self):
        pass  # shared in-process connection — don't close


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def _insert_s3(db: FakeDbManager, ticker: str, passed: bool, routing_status: str,
               routed_types: list[str] | None = None, fail_reasons: list[str] | None = None,
               feature_ready: bool = True):
    db._conn.execute(
        "INSERT INTO step3_candidates VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        [
            str(uuid.uuid4()), RUN_ID, ticker, SIG_DATE.isoformat(),
            0.5, passed, routing_status, None,
            json.dumps(fail_reasons or []),
            json.dumps(routed_types or []),
            json.dumps({"feature_ready": feature_ready}),
            datetime.now().isoformat(),
        ],
    )


def _insert_s4(db: FakeDbManager, ticker: str, setup_type: str, passed: bool,
               fail_reason: str | None = None):
    db._conn.execute(
        "INSERT INTO step4_analysis (analysis_id, candidate_id, run_id, setup_config_id, "
        "ticker, signal_date, setup_type, setup_score, setup_passed, setup_fail_reason, "
        "created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        [
            str(uuid.uuid4()), str(uuid.uuid4()), RUN_ID, f"setup_{setup_type}_v1",
            ticker, SIG_DATE.isoformat(), setup_type, 70.0, passed,
            fail_reason, datetime.now().isoformat(),
        ],
    )


def _insert_s5(db: FakeDbManager, ticker: str, setup_type: str,
               risk_label: str, disposition: str):
    db._conn.execute(
        "INSERT INTO step5_proposals (proposal_id, run_id, setup_config_id, ticker, "
        "signal_date, setup_type, disposition, in_raw_top_n, in_diversified_top_n, "
        "diversification_applied, selected_top_n, selected_flag, ai_reviewed, "
        "executed_flag, risk_label, created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [
            str(uuid.uuid4()), RUN_ID, f"setup_{setup_type}_v1", ticker,
            SIG_DATE.isoformat(), setup_type, disposition,
            True, True, True, True, True, False, False,
            risk_label, datetime.now().isoformat(),
        ],
    )


def build_svc(db: FakeDbManager) -> SetupModeFunnelDiagnosticsService:
    return SetupModeFunnelDiagnosticsService(db_manager=db)


# --------------------------------------------------------------------------- #
# Active setup types
# --------------------------------------------------------------------------- #
def test_active_setup_types_are_canonical():
    assert set(ACTIVE_SETUP_TYPES) == {
        "breakout", "pullback", "trend_continuation", "consolidation_base"
    }


def test_conservative_consolidation_not_in_active_types():
    assert "conservative_consolidation" not in ACTIVE_SETUP_TYPES


# --------------------------------------------------------------------------- #
# db_role validation
# --------------------------------------------------------------------------- #
def test_invalid_db_role_returns_failed():
    db = FakeDbManager()
    svc = build_svc(db)
    result = svc.run(signal_date=SIG_DATE, db_role="simulation", run_id=RUN_ID)
    assert result.status == "failed"
    assert result.errors


def test_valid_prod_role_accepted():
    db = FakeDbManager()
    svc = build_svc(db)
    result = svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    assert result.status in ("success", "success_with_warnings")


def test_valid_debug_role_accepted():
    db = FakeDbManager()
    svc = build_svc(db)
    result = svc.run(signal_date=SIG_DATE, db_role="debug", run_id=RUN_ID)
    assert result.status in ("success", "success_with_warnings")


# --------------------------------------------------------------------------- #
# Empty pipeline data
# --------------------------------------------------------------------------- #
def test_empty_pipeline_returns_success():
    """Empty pipeline (no rows for this run_id) still succeeds.
    Zero-value metrics (risk_label.low=0, etc.) are valid and written.
    """
    db = FakeDbManager()
    svc = build_svc(db)
    result = svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    assert result.status in ("success", "success_with_warnings")


# --------------------------------------------------------------------------- #
# Eligibility metrics
# --------------------------------------------------------------------------- #
def test_eligibility_total_input_metric():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s3(db, "MSFT", False, "ineligible", fail_reasons=["price_below_min"])
    svc = build_svc(db)
    result = svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    assert result.status in ("success", "success_with_warnings")
    rows = svc.read(RUN_ID, SIG_DATE, db_role="prod")
    total_row = next((r for r in rows if r["metric_name"] == "eligibility.total_input"), None)
    assert total_row is not None, "eligibility.total_input must be present"
    assert total_row["metric_value"] == 2.0


def test_eligibility_passed_metric():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s3(db, "MSFT", False, "ineligible", fail_reasons=["price_below_min"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    passed_row = next((r for r in rows if r["metric_name"] == "eligibility.passed"), None)
    assert passed_row is not None
    assert passed_row["metric_value"] == 1.0


def test_eligibility_failed_metric():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s3(db, "GOOG", False, "ineligible", fail_reasons=["price_below_min"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    failed_row = next((r for r in rows if r["metric_name"] == "eligibility.failed"), None)
    assert failed_row is not None
    assert failed_row["metric_value"] == 1.0


def test_eligibility_rejection_reason_metric():
    db = FakeDbManager()
    _insert_s3(db, "T1", False, "ineligible", fail_reasons=["price_below_min"])
    _insert_s3(db, "T2", False, "ineligible", fail_reasons=["price_below_min", "data_quality_fail"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    price_row = next(
        (r for r in rows if r["metric_name"] == "eligibility.rejection_reason.price_below_min"), None
    )
    assert price_row is not None
    assert price_row["metric_value"] == 2.0


# --------------------------------------------------------------------------- #
# Routing metrics
# --------------------------------------------------------------------------- #
def test_routing_not_routed_metric():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s3(db, "MSFT", True, "no_route", [])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    not_routed = next((r for r in rows if r["metric_name"] == "routing.not_routed"), None)
    assert not_routed is not None
    assert not_routed["metric_value"] == 1.0


def test_routing_counts_by_setup_type():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s3(db, "MSFT", True, "routed", ["breakout", "trend_continuation"])
    _insert_s3(db, "NVDA", True, "routed", ["pullback"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    # Check breakout routing count
    bo_row = next(
        (r for r in rows if r["metric_name"] == "routing.routed" and r["setup_type"] == "breakout"), None
    )
    assert bo_row is not None
    assert bo_row["metric_value"] == 2.0


def test_routing_consolidation_base_named_correctly():
    """Must be 'consolidation_base' not 'conservative_consolidation'."""
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["consolidation_base"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    cb_row = next(
        (r for r in rows if r["setup_type"] == "consolidation_base" and r["metric_name"] == "routing.routed"),
        None
    )
    assert cb_row is not None, "consolidation_base routing count must be present"
    # Must NOT have conservative_consolidation
    for r in rows:
        assert r["setup_type"] != "conservative_consolidation", \
            "conservative_consolidation must not appear in diagnostic output"


# --------------------------------------------------------------------------- #
# Validation metrics
# --------------------------------------------------------------------------- #
def test_validation_pass_fail_by_setup_type():
    db = FakeDbManager()
    _insert_s4(db, "AAPL", "breakout", True)
    _insert_s4(db, "MSFT", "breakout", False, fail_reason="rvol_too_low")
    _insert_s4(db, "NVDA", "pullback", True)
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)

    bo_pass = next(
        (r for r in rows if r["metric_name"] == "validation.passed" and r["setup_type"] == "breakout"), None
    )
    bo_fail = next(
        (r for r in rows if r["metric_name"] == "validation.failed" and r["setup_type"] == "breakout"), None
    )
    pu_pass = next(
        (r for r in rows if r["metric_name"] == "validation.passed" and r["setup_type"] == "pullback"), None
    )
    assert bo_pass is not None and bo_pass["metric_value"] == 1.0
    assert bo_fail is not None and bo_fail["metric_value"] == 1.0
    assert pu_pass is not None and pu_pass["metric_value"] == 1.0


def test_validation_failure_reasons_by_setup_type():
    db = FakeDbManager()
    _insert_s4(db, "AAPL", "breakout", False, "rvol_too_low")
    _insert_s4(db, "MSFT", "breakout", False, "rvol_too_low")
    _insert_s4(db, "NVDA", "breakout", False, "stop_distance_too_large")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    rvol_row = next(
        (r for r in rows
         if r["metric_name"] == "validation.failure_reason.rvol_too_low"
         and r["setup_type"] == "breakout"),
        None
    )
    assert rvol_row is not None
    assert rvol_row["metric_value"] == 2.0


# --------------------------------------------------------------------------- #
# Risk label and disposition metrics
# --------------------------------------------------------------------------- #
def test_risk_label_counts_present():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "low", "BUY")
    _insert_s5(db, "MSFT", "pullback", "medium", "BUY")
    _insert_s5(db, "NVDA", "trend_continuation", "high", "WATCHLIST_ONLY")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)

    for label in ("low", "medium", "high"):
        rl_row = next((r for r in rows if r["metric_name"] == f"risk_label.{label}"), None)
        assert rl_row is not None, f"risk_label.{label} must be present"

    low = next(r for r in rows if r["metric_name"] == "risk_label.low")
    med = next(r for r in rows if r["metric_name"] == "risk_label.medium")
    high = next(r for r in rows if r["metric_name"] == "risk_label.high")
    assert low["metric_value"] == 1.0
    assert med["metric_value"] == 1.0
    assert high["metric_value"] == 1.0


def test_buy_eligible_count_metric():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "low", "BUY")
    _insert_s5(db, "MSFT", "pullback", "medium", "BUY")
    _insert_s5(db, "NVDA", "trend_continuation", "high", "WATCHLIST_ONLY")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    buy_row = next((r for r in rows if r["metric_name"] == "proposal.buy_eligible"), None)
    assert buy_row is not None
    assert buy_row["metric_value"] == 2.0


def test_watchlist_count_metric():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "low", "BUY")
    _insert_s5(db, "MSFT", "pullback", "high", "WATCHLIST_ONLY")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    wl_row = next((r for r in rows if r["metric_name"] == "proposal.watchlist"), None)
    assert wl_row is not None
    assert wl_row["metric_value"] == 1.0


def test_rejected_count_metric():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "high", "REJECTED")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    rej_row = next((r for r in rows if r["metric_name"] == "proposal.rejected"), None)
    assert rej_row is not None
    assert rej_row["metric_value"] == 1.0


def test_final_proposal_count_metric():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "low", "BUY")
    _insert_s5(db, "MSFT", "pullback", "medium", "WATCHLIST_ONLY")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    fc_row = next((r for r in rows if r["metric_name"] == "proposal.final_count"), None)
    assert fc_row is not None
    assert fc_row["metric_value"] == 2.0


# --------------------------------------------------------------------------- #
# Required minimum metrics checklist (Phase 6 spec)
# --------------------------------------------------------------------------- #
def test_all_required_diagnostic_metrics_present():
    """Verify every required metric from the Phase 6 prompt is present."""
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s3(db, "MSFT", False, "ineligible", fail_reasons=["price_below_min"])
    _insert_s3(db, "GOOG", True, "no_route", [])
    _insert_s4(db, "AAPL", "breakout", True)
    _insert_s5(db, "AAPL", "breakout", "low", "BUY")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    metric_names = {r["metric_name"] for r in rows}

    required = {
        "eligibility.total_input",
        "eligibility.passed",
        "eligibility.failed",
        "routing.not_routed",
        "risk_label.low",
        "risk_label.medium",
        "risk_label.high",
        "proposal.buy_eligible",
        "proposal.watchlist",
        "proposal.rejected",
        "proposal.final_count",
    }
    # routing.routed must exist for at least one setup type
    has_routing_routed = any(n == "routing.routed" for n in metric_names)
    # validation.passed must exist for at least one setup type
    has_validation = any(n in ("validation.passed", "validation.failed") for n in metric_names)

    missing = required - metric_names
    assert not missing, f"Required diagnostic metrics missing: {missing}"
    assert has_routing_routed, "routing.routed (per setup_type) must be present"
    assert has_validation, "validation.passed or validation.failed must be present"


# --------------------------------------------------------------------------- #
# Metric rows structure
# --------------------------------------------------------------------------- #
def test_diagnostic_rows_have_required_columns():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    assert rows, "must have at least one row"
    required_keys = {"step_name", "setup_type", "metric_name", "metric_value", "reason", "metadata_json"}
    for r in rows:
        assert required_keys <= set(r.keys()), f"Row missing keys: {required_keys - set(r.keys())}"


def test_no_old_strategy_terms_in_metric_names():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    _insert_s4(db, "AAPL", "breakout", True)
    _insert_s5(db, "AAPL", "breakout", "low", "BUY")
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    for r in rows:
        name = (r["metric_name"] or "").lower()
        stype = (r["setup_type"] or "").lower()
        for bad in ("aggressive", "normal", "conservative", "strategy_config_id"):
            assert bad not in name, f"Old strategy term '{bad}' in metric_name: {r['metric_name']}"
            assert bad not in stype, f"Old strategy term '{bad}' in setup_type: {r['setup_type']}"


def test_rows_processed_equals_metrics_written():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    svc = build_svc(db)
    result = svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    assert result.rows_processed == len(rows)


# --------------------------------------------------------------------------- #
# Legacy alias
# --------------------------------------------------------------------------- #
def test_legacy_alias_resolves_to_setup_mode_class():
    assert FunnelDiagnosticsService is SetupModeFunnelDiagnosticsService


# --------------------------------------------------------------------------- #
# Schema: pipeline_run_diagnostics table columns
# --------------------------------------------------------------------------- #
def test_pipeline_run_diagnostics_schema():
    db = FakeDbManager()
    _insert_s3(db, "AAPL", True, "routed", ["breakout"])
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    # Verify actual schema columns
    cols_result = db._conn.execute(
        "SELECT column_name FROM information_schema.columns "
        "WHERE table_name = 'pipeline_run_diagnostics'"
    ).fetchall()
    col_names = {r[0] for r in cols_result}
    required = {
        "diag_id", "run_id", "signal_date", "db_role", "step_name",
        "setup_type", "metric_name", "metric_value", "reason", "metadata_json", "created_at"
    }
    assert required <= col_names, f"Missing schema columns: {required - col_names}"


# ===========================================================================
# Phase 6 additions: rejection reasons, risk failure breakdown, config
# snapshot, timing
# ===========================================================================

# ---------------------------------------------------------------------------
# Proposal rejection reasons
# ---------------------------------------------------------------------------
def test_proposal_rejection_reason_metrics():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "high", "REJECTED")
    _insert_s5(db, "MSFT", "pullback", "high", "REJECTED")
    # Manually set rejection_reason on the REJECTED rows
    db._conn.execute(
        "UPDATE step5_proposals SET rejection_reason = 'setup_failed' WHERE ticker = 'AAPL'"
    )
    db._conn.execute(
        "UPDATE step5_proposals SET rejection_reason = 'rvol_gate' WHERE ticker = 'MSFT'"
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    names = {r["metric_name"] for r in rows}
    assert "proposal.rejection_reason.setup_failed" in names
    assert "proposal.rejection_reason.rvol_gate" in names


def test_proposal_rejection_reason_count():
    db = FakeDbManager()
    _insert_s5(db, "AAPL", "breakout", "high", "REJECTED")
    _insert_s5(db, "MSFT", "breakout", "high", "REJECTED")
    db._conn.execute(
        "UPDATE step5_proposals SET rejection_reason = 'setup_failed'"
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    sf_row = next((r for r in rows if r["metric_name"] == "proposal.rejection_reason.setup_failed"), None)
    assert sf_row is not None
    assert sf_row["metric_value"] == 2.0


# ---------------------------------------------------------------------------
# Risk failure breakdown
# ---------------------------------------------------------------------------
def test_risk_failure_reason_metrics_present():
    db = FakeDbManager()
    # Insert a proposal with risk_reasons JSON
    proposal_id = str(uuid.uuid4())
    db._conn.execute(
        "INSERT INTO step5_proposals (proposal_id, run_id, setup_config_id, ticker, "
        "signal_date, setup_type, disposition, in_raw_top_n, in_diversified_top_n, "
        "diversification_applied, selected_top_n, selected_flag, ai_reviewed, "
        "executed_flag, risk_label, risk_reasons, created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [
            proposal_id, RUN_ID, "setup_breakout_v1", "AAPL",
            SIG_DATE.isoformat(), "breakout", "WATCHLIST_ONLY",
            False, False, True, False, False, False, False,
            "high",
            json.dumps(["stop_distance_pct=55.0", "estimated_rr=12.3", "atr_pct=88.0"]),
            datetime.now().isoformat(),
        ],
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    names = {r["metric_name"] for r in rows}
    # stop_distance_pct → stop.failure_reason.*
    assert any("stop.failure_reason" in n for n in names), f"Expected stop.failure_reason.* in {names}"
    # estimated_rr → rr.failure_reason.*
    assert any("rr.failure_reason" in n for n in names), f"Expected rr.failure_reason.* in {names}"
    # atr_pct → risk.failure_reason.*
    assert any("risk.failure_reason" in n for n in names), f"Expected risk.failure_reason.* in {names}"


def test_risk_failure_reason_no_old_strategy_terms():
    db = FakeDbManager()
    db._conn.execute(
        "INSERT INTO step5_proposals (proposal_id, run_id, setup_config_id, ticker, "
        "signal_date, setup_type, disposition, in_raw_top_n, in_diversified_top_n, "
        "diversification_applied, selected_top_n, selected_flag, ai_reviewed, "
        "executed_flag, risk_label, risk_reasons, created_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        [
            str(uuid.uuid4()), RUN_ID, "setup_breakout_v1", "NVDA",
            SIG_DATE.isoformat(), "breakout", "BUY",
            True, True, True, True, True, False, False,
            "low",
            json.dumps(["stop_distance_pct=10.0"]),
            datetime.now().isoformat(),
        ],
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    for r in rows:
        name = (r["metric_name"] or "").lower()
        for bad in ("aggressive", "normal", "conservative"):
            assert bad not in name


# ---------------------------------------------------------------------------
# Config snapshot
# ---------------------------------------------------------------------------
def test_config_snapshot_rows_written():
    db = FakeDbManager()
    # Seed setup_configs table
    db._conn.execute(
        "CREATE TABLE IF NOT EXISTS setup_configs ("
        "config_id VARCHAR PRIMARY KEY, setup_type VARCHAR NOT NULL, "
        "version VARCHAR NOT NULL, parent_config_id VARCHAR, "
        "config_json JSON NOT NULL, config_hash VARCHAR NOT NULL, "
        "active_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL, notes TEXT)"
    )
    db._conn.execute(
        "CREATE TABLE IF NOT EXISTS risk_label_config ("
        "config_id VARCHAR PRIMARY KEY, version VARCHAR NOT NULL, "
        "config_json JSON NOT NULL, config_hash VARCHAR NOT NULL, "
        "active_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL, notes TEXT)"
    )
    for st in ("breakout", "pullback", "trend_continuation", "consolidation_base"):
        db._conn.execute(
            "INSERT INTO setup_configs (config_id, setup_type, version, config_json, "
            "config_hash, active_flag, created_at) VALUES (?,?,?,?,?,TRUE,?)",
            [f"setup_{st}_v1", st, "v1", "{}", "abc123", datetime.now().isoformat()],
        )
    db._conn.execute(
        "INSERT INTO risk_label_config (config_id, version, config_json, config_hash, "
        "active_flag, created_at) VALUES (?,?,?,?,TRUE,?)",
        ["risk_label_config_v1", "risk_v1", "{}", "def456", datetime.now().isoformat()],
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    config_rows = [r for r in rows if r["step_name"] == "config_snapshot"]
    # 4 setup configs + 1 risk_label_config = 5 config rows
    assert len(config_rows) >= 5, f"Expected >=5 config rows, got {len(config_rows)}"


def test_config_snapshot_has_metadata_json():
    db = FakeDbManager()
    db._conn.execute(
        "CREATE TABLE IF NOT EXISTS setup_configs ("
        "config_id VARCHAR PRIMARY KEY, setup_type VARCHAR NOT NULL, "
        "version VARCHAR NOT NULL, parent_config_id VARCHAR, "
        "config_json JSON NOT NULL, config_hash VARCHAR NOT NULL, "
        "active_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL, notes TEXT)"
    )
    db._conn.execute(
        "CREATE TABLE IF NOT EXISTS risk_label_config ("
        "config_id VARCHAR PRIMARY KEY, version VARCHAR NOT NULL, "
        "config_json JSON NOT NULL, config_hash VARCHAR NOT NULL, "
        "active_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL, notes TEXT)"
    )
    db._conn.execute(
        "INSERT INTO setup_configs (config_id, setup_type, version, config_json, "
        "config_hash, active_flag, created_at) VALUES (?,?,?,?,?,TRUE,?)",
        ["setup_breakout_v1", "breakout", "breakout_v1", "{}", "abc123", datetime.now().isoformat()],
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    config_rows = [r for r in rows if r["step_name"] == "config_snapshot"]
    assert config_rows, "config_snapshot rows must be present"
    meta = config_rows[0]["metadata_json"]
    if isinstance(meta, str):
        meta = json.loads(meta)
    assert "config_id" in meta
    assert "version" in meta
    assert "config_hash" in meta


def test_config_snapshot_consolidation_base_not_conservative():
    db = FakeDbManager()
    db._conn.execute(
        "CREATE TABLE IF NOT EXISTS setup_configs ("
        "config_id VARCHAR PRIMARY KEY, setup_type VARCHAR NOT NULL, "
        "version VARCHAR NOT NULL, parent_config_id VARCHAR, "
        "config_json JSON NOT NULL, config_hash VARCHAR NOT NULL, "
        "active_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL, notes TEXT)"
    )
    db._conn.execute(
        "CREATE TABLE IF NOT EXISTS risk_label_config ("
        "config_id VARCHAR PRIMARY KEY, version VARCHAR NOT NULL, "
        "config_json JSON NOT NULL, config_hash VARCHAR NOT NULL, "
        "active_flag BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL, notes TEXT)"
    )
    db._conn.execute(
        "INSERT INTO setup_configs (config_id, setup_type, version, config_json, "
        "config_hash, active_flag, created_at) VALUES (?,?,?,?,?,TRUE,?)",
        ["setup_consolidation_base_v1", "consolidation_base", "v1", "{}", "xyz", datetime.now().isoformat()],
    )
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID)
    rows = svc.read(RUN_ID, SIG_DATE)
    for r in rows:
        st = (r.get("setup_type") or "").lower()
        assert "conservative_consolidation" not in st
        meta_raw = r.get("metadata_json") or ""
        meta_str = json.dumps(meta_raw) if not isinstance(meta_raw, str) else meta_raw
        assert "conservative_consolidation" not in meta_str


# ---------------------------------------------------------------------------
# Step timing metrics
# ---------------------------------------------------------------------------
def test_timing_rows_written_for_all_supplied_steps():
    db = FakeDbManager()
    timings = {
        "step3_universal_eligibility": 4.2,
        "step4_setup_validation": 12.7,
        "step5_proposals": 3.1,
        "feature_calculation": 8.9,
    }
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID, step_timings=timings)
    rows = svc.read(RUN_ID, SIG_DATE)
    names = {r["metric_name"] for r in rows}
    for step_name in timings:
        key = f"timing.step_duration_sec.{step_name}"
        assert key in names, f"Expected timing row for {step_name}"


def test_timing_values_match_supplied():
    db = FakeDbManager()
    timings = {"step3_universal_eligibility": 4.2, "step5_proposals": 3.1}
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID, step_timings=timings)
    rows = svc.read(RUN_ID, SIG_DATE)
    s3_row = next((r for r in rows if r["metric_name"] == "timing.step_duration_sec.step3_universal_eligibility"), None)
    s5_row = next((r for r in rows if r["metric_name"] == "timing.step_duration_sec.step5_proposals"), None)
    assert s3_row is not None
    assert abs(s3_row["metric_value"] - 4.2) < 0.01
    assert s5_row is not None
    assert abs(s5_row["metric_value"] - 3.1) < 0.01


def test_timing_step_name_is_step_timing():
    db = FakeDbManager()
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID,
            step_timings={"step4_setup_validation": 9.9})
    rows = svc.read(RUN_ID, SIG_DATE)
    timing_rows = [r for r in rows if r["step_name"] == "pipeline_timing"]
    assert timing_rows, "timing rows must have step_name = 'pipeline_timing'"


def test_no_timing_rows_when_no_timings_supplied():
    db = FakeDbManager()
    svc = build_svc(db)
    svc.run(signal_date=SIG_DATE, db_role="prod", run_id=RUN_ID, step_timings=None)
    rows = svc.read(RUN_ID, SIG_DATE)
    timing_rows = [r for r in rows if "timing.step_duration_sec" in (r["metric_name"] or "")]
    assert len(timing_rows) == 0


# ---------------------------------------------------------------------------
# Orchestrator passes timings to diagnostics (integration-level check)
# ---------------------------------------------------------------------------
def test_orchestrator_passes_step_timings_to_diagnostics():
    """The FakeDiagnostics spy verifies step_timings is forwarded from orchestrator."""
    import sys
    sys.path.insert(0, "/home/claude/phase6")
    from app.services.pipeline.pipeline_orchestrator import PipelineOrchestrator
    from app.utils import service_result as sr2
    from app.utils.service_result import ServiceResult as SR

    class SpyDiagnostics:
        def __init__(self):
            self.calls = []
        def run(self, **kwargs):
            self.calls.append(kwargs)
            return SR(status=sr2.STATUS_SUCCESS, run_id="d")

    class FakeDb2:
        def __init__(self):
            self.executed = []
            self.closed = 0
        def connect(self, db_role, read_only=False):
            return _FakeConn2(self)

    class _FakeConn2:
        def __init__(self, db):
            self._db = db
        def execute(self, sql, params=None):
            self._db.executed.append(sql)
            return _FakeCursor2()
        def close(self):
            self._db.closed += 1

    class _FakeCursor2:
        def fetchone(self): return None
        def fetchall(self): return []

    class FakeEng2:
        def load(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def apply_snapshot(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def ingest(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def validate(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def detect(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def calculate(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def classify(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def run(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def propose(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def enqueue(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def process(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x")
        def list_symbols(self, **kw): return SR(status=sr2.STATUS_SUCCESS, run_id="x", metadata={"symbols": []})

    spy = SpyDiagnostics()
    db = FakeDb2()
    eng = FakeEng2()
    orch = PipelineOrchestrator(
        db_manager=db, provider=eng,
        benchmark_loader=eng, universe_engine=eng, ingestion_engine=eng,
        validation_engine=eng, mutation_engine=eng, feature_engine=eng,
        regime_engine=eng, eligibility_engine=eng,
        setup_validation_engine=eng, proposal_engine=eng,
        outcome_creator=eng, outcome_processor=eng,
        config_service=None, diagnostics_service=spy,
    )
    orch.run(date(2026, 6, 15), run_id="timing-test")

    assert spy.calls, "diagnostics must be called"
    timings = spy.calls[0].get("step_timings", {})
    assert "step3_universal_eligibility" in timings, "step3 timing must be forwarded"
    assert "step4_setup_validation" in timings, "step4 timing must be forwarded"
    assert "step5_proposals" in timings, "step5 timing must be forwarded"
    for v in timings.values():
        assert isinstance(v, float) and v >= 0.0
