"""Database subpackage: centralized DuckDB connection management.

Module 02 (DuckDB Manager) lives here. Per ``CODING_STANDARDS.md`` section 8,
this is the single approved place to open DuckDB connections; no other module
opens arbitrary database paths directly.

Scope (Module 02): connection management only. No schema creation, no
migrations, no provider calls, and no trading logic. Module 03 (Schema Manager)
is responsible for creating the final merged schema.
"""
