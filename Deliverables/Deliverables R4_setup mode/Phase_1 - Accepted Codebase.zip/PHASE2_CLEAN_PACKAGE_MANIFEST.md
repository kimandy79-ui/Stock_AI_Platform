# Phase 2 Clean Coder Package

This package combines the supplied latest codebase and SoT docs for Phase 2 — Features v02.

## Removed as non-critical/generated/scratch

- `.pytest_cache/`
- `scratch_1.py`
- `clear_pyc.py`
- `check_orchestrator_import.py`
- `check_regime_symbols.py`
- `find_regime.py`
- `find_wrong_import.py`
- `tools/run_prod_pipeline1.py`
- `SoT/Stock_AI_Platform_legacy strategy-mode stable codebase.zip`

## Kept

- `app/` source code
- `tests/`
- `tools/` canonical runner/init/backfill scripts
- root module specs and README/requirements/pyproject
- `SoT/` setup-first source-of-truth docs

## Note to coder

Use this package as the Phase 2 input baseline. Do not rely on memory or old strategy-mode code. If Phase 0/Phase 1 content is missing or inconsistent, report the blocker before coding.
