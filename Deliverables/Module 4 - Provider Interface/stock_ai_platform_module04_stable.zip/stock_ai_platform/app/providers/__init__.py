"""Provider layer for the Swing Trading Stock Analyzer.

Module 04 scope: the *abstract* provider contract only. This package defines
the provider-neutral :class:`MarketDataProvider` interface, its request/response
DTOs, and the structured error vocabulary that downstream modules depend on.

No concrete provider (e.g. YahooProvider, Module 05), no ``yfinance``, no
network client, and no DuckDB access live here. See
``PROVIDER_INTERFACE_SPEC.md`` for the source-of-truth contract.
"""

from __future__ import annotations

from app.providers.provider_interface import (
    EARNINGS_SESSIONS,
    PROVIDER_ERROR_KINDS,
    EarningsEvent,
    MarketDataProvider,
    PriceBar,
    PriceHistoryRequest,
    ProviderCapabilities,
    ProviderErrorDetail,
    TickerInfo,
)

__all__ = [
    "MarketDataProvider",
    "PriceBar",
    "PriceHistoryRequest",
    "TickerInfo",
    "EarningsEvent",
    "ProviderCapabilities",
    "ProviderErrorDetail",
    "PROVIDER_ERROR_KINDS",
    "EARNINGS_SESSIONS",
]
